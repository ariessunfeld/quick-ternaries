"""Main entrypoint for ternary GUI application"""
"""NOTE this will work once we ensure that on startup, views are flushed to reflect current model.
That's not currently the case. For now, we should continue using main.py"""
import sys
import os
import pickle

from PySide6.QtWidgets import QApplication

from src.models.app_state import AppModel
from src.views.main_window import MainWindow
from src.controllers.app_controller import AppController

MODEL_FILE = "model.pkl"

def load_model():
    """Load the model from a pickle file if it exists."""
    if os.path.exists(MODEL_FILE):
        with open(MODEL_FILE, "rb") as f:
            return pickle.load(f)
    else:
        return AppModel()

def save_model(model):
    """Save the model to a pickle file."""
    with open(MODEL_FILE, "wb") as f:
        pickle.dump(model, f)

def main():
    app = QApplication(sys.argv)
    
    # Load or instantiate the model
    app_model = load_model()  # Model
    main_window = MainWindow()  # View
    app_controller = AppController(app_model, main_window)  # Controller

    # Ensure the model is saved when the application is about to exit
    app.aboutToQuit.connect(lambda: save_model(app_model))

    main_window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()

