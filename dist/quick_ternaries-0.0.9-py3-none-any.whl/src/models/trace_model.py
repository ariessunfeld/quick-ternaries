"""Contains Model for Trace views of GUI (where specific data is selected, point size/color is chosen, filters, conversion, heatmap, etc)"""
