"""Contains Model representing global application state"""
