# Future entrypoint for the app

# from gui import GUI
# from ...

if __name__ == '__main__':
    pass
    # Instantiate GUI
    # Instantiate and connect Backend as necessary (if not handled in GUI)
    # Read about Model View Controller design
    # GUI.run()?
