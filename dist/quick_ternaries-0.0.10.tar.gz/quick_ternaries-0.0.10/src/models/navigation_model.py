"""Contains the Model for the navigation panel (part of GUI that manages adding/deleting/moving traces)"""

