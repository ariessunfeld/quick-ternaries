class CartesianTraceEditorController:
    pass
