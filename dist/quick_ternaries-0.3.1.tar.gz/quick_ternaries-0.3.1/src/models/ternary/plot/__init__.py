from .model import TernaryRenderPlotModel

__all__ = [
    "TernaryRenderPlotModel"
]
