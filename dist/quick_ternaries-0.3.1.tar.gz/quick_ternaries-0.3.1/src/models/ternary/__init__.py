from .model import TernaryModel

__all__ = [
    "TernaryModel"
]
