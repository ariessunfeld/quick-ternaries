"""Contains the TraceView(QWidget) class, which contains the widgets needed for configuring individual traces, and is used in the dynamic content area of the MainWindow"""

