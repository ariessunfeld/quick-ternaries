"""Contains Model for the Setup part of the GUI (part where data loading, ternary apex selection, apex display name, and title are set)"""
