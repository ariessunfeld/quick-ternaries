from .controller import TernaryController

__all__ = [
    "TernaryController"
]
