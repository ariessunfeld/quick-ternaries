class TernaryRenderPlotModel:
    def __init__(self):
        self.html_path = None

    def set_html_path(self, path: str):
        self.html_path = path

